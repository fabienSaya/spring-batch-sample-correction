package com.bnpparibas.bcefit.factory.training.springbatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication
public class MainStarter {

    public static void main(String[] args) {
        SpringApplication.run(MainStarter.class, args);
    }
}
